word-editor local WASM verification package

This package is for free local preview only.

Run:

  node serve-localhost.mjs

Open:

  http://127.0.0.1:8789/

Notes:

- The editor core is sealed in wasm/word-editor-local-core.wasm.
- The runtime license only allows http://127.0.0.1:* and http://localhost:*.
- The server binds to 127.0.0.1 and rejects non-local Host headers.
- Do not deploy this package to a public web host.
